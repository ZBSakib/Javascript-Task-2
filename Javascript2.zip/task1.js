class Student{
    constructor(name, birthdate, address, phonenumber){
        this.name=name;
        this.birthdate=birthdate;
        this.address=address;
        this.phonenumber=phonenumber;

    }

    get studentName(){
        return this.name;
    }
    set studentName(name){
        this.name=name;
    }
    get studentBirthdate(){
        return this.birthdate;
    }
    set studentBirthdate(birthdate){
        this.birthdate=birthdate;
    }
    get studentAddress(){
        return this.address;
    }
    set studentAddress(address){
        this.address=address;
    }
    get studentPhonenumber(){
        
        return this.number;
    }
    set studentPhonenumber(phonenumber){
        this.name=phonenumber;
    }

    get print(){
        return console.log("Name: " + this.name + "\n" + "Birthdate: " + this.birthdate + "\n" + "Address: " + this.address + "\n" + "Phonenumber: "+this.phonenumber);
    }

    get countAge(){
    var date = new Date();
    var age = date.getFullYear() - this.birthdate;
    var a = date.getMonth() -this.birthdate;
    if (a < 0 || (a === 0 && date.getDate() < this.birthdate())) 
    {
        age--;
    }
   
    return age;
    }
}

var student=new Student ( "Sakib",(03,12,1997), "Taivaanpankontie 14 A 6/2",1234567890);
console.log(student.countAge);
console.log(student.print);


