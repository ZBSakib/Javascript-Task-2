var print = function (name, address, birthdate, phonenumber) {
    return console.log("Name: " + name + "\n" + "Birthdate: " + birthdate + "\n" + "Address: " + address + "\n" + "Phonenumber: "+phonenumber);
  };

  print("Sakib","Taivaapankontie 14 A 6/2","03/12/1997",123456)

  var countAge = function () {
    var today = new Date();
    var birthDate = new Date(1997,12,03);
    var age = today.getFullYear() - birthDate.getFullYear();
    var a = today.getMonth() - birthDate.getMonth();
    if (a < 0 || (a === 0 && today.getDate() < birthDate.getDate())) 
    {
        age--;
    }
    console.log(age);
    return age;
}
  countAge();