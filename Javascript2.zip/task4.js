class Grade{
    constructor(course, grade, passDate){
        this.course=course;
        if(grade>=0 && grade<=10){
            this.grade=grade;
        }
        else{
            this.grade=0 ;
        }
        this.passDate=passDate;
    }
}

class Student{
    constructor(){
        this.grade=[];
    }


addGrade(grade) 
    {
        this.grade.push(grade);  
    }

printGrades(){
     this.grade.forEach(element => {
            console.log(" Course:" +element.course + "," +" Grade: " + element.grade +"," + "Passing date: " +element.passDate.toLocaleDateString("en-US"));});
    }

    passedCourses(){
        return this.grade.every((grade) => {return grade.grade>=1;});
    }
    goodStudent(){
        return this.grade.some((grade) => {return grade.grade==5;});
    }
    giveGradesScaled(){
        return this.grade.map((grade) => {return Math.round( grade.grade/2);})
    }
    
}



var student=new Student();
var grade1=new Grade("Browser Programming", 8, new Date("2021-12-07"));
var grade2=new Grade("Mathmatics 3", 9, new Date("2021-12-14"));
var grade3=new Grade("Physics for engineering", 10, new Date("2021-12-21"));
student.addGrade(grade1);
student.addGrade(grade2);
student.addGrade(grade3);
student.printGrades();
console.log(student.passedCourses());
console.log(student.goodStudent());
console.log(student.giveGradesScaled()) ;

  